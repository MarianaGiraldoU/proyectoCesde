/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cajero;

/**
 *
 * @author desarrollo
 */
public class main {

    public static void main(String[] args) {
        System.out.println("Hello Welcom the Cajero!");
        
        Transaccion.retiro(50000, 20000, 0001, true);
        Transaccion
    }
}
